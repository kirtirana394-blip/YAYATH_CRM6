function toggleNav(){document.querySelector('.sidebar')?.classList.toggle('open')}
function confirmDelete(msg){return confirm(msg||'Are you sure you want to delete this lead?')}
async function refreshDashboard(){const el=document.querySelector('[data-live-dashboard]');if(!el)return;try{const r=await fetch('/api/dashboard');if(!r.ok)return;const d=await r.json();document.querySelectorAll('[data-kpi="total"]').forEach(x=>x.textContent=d.total)}catch(e){}}
setInterval(refreshDashboard,30000);
document.addEventListener('click',e=>{if(e.target.closest('.sidebar a')&&window.innerWidth<901)document.querySelector('.sidebar')?.classList.remove('open')})
