import os
import tempfile
import pytest
from app import app
from models import db, User, Lead

@pytest.fixture
def client():
    dbfile = tempfile.NamedTemporaryFile(delete=False, suffix='.db'); dbfile.close()
    app.config.update(TESTING=True, SQLALCHEMY_DATABASE_URI='sqlite:///' + dbfile.name, SECRET_KEY='test')
    with app.app_context():
        db.drop_all(); db.create_all()
        u=User(full_name='Admin',email='admin@test.local',role='admin'); u.set_password('pass'); db.session.add(u); db.session.commit()
    with app.test_client() as c:
        yield c
    os.unlink(dbfile.name)

def login(c):
    return c.post('/login', data={'email':'admin@test.local','password':'pass'}, follow_redirects=True)

def test_login_and_add_lead(client):
    r=login(client); assert b'Dashboard' in r.data
    r=client.post('/leads/new', data={'full_name':'Test Lead','phone':'9876543210'}, follow_redirects=True)
    assert b'Test Lead' in r.data
    with app.app_context():
        lead=Lead.query.filter_by(full_name='Test Lead').first(); assert lead.source=='99Acres'

def test_export_csv(client):
    login(client); client.post('/leads/new', data={'full_name':'Export Lead','phone':'9876543211'}, follow_redirects=True)
    r=client.get('/export/leads?format=csv'); assert r.status_code==200; assert b'99Acres' in r.data
