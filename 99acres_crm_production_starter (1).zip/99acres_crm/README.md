# 99Acres Lead Management CRM

Production-oriented Flask CRM for 99Acres leads. Persistent data is stored with SQLAlchemy and can run on SQLite for local setup or PostgreSQL for production. The app enforces `source = 99Acres`, uses soft delete for leads/properties, role-aware server routes, real search/filter/pagination, follow-up buckets based on current date, task management, notes/timeline, Excel/CSV import preview, duplicate protection, and Excel/CSV export.

## Run locally
1. Create a virtual environment.
2. `pip install -r requirements.txt`
3. Copy `.env.example` to `.env` and change `SECRET_KEY`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD`.
4. `flask --app app init-db`
5. `python app.py`
6. Open `http://127.0.0.1:5000/login`

## PostgreSQL
Set `DATABASE_URL=postgresql+psycopg://USER:PASSWORD@HOST:5432/DBNAME` in the environment. For Docker, `docker compose up --build` starts PostgreSQL and the CRM.

## Production hardening
Run behind HTTPS/reverse proxy, set a strong random SECRET_KEY, use PostgreSQL, restrict database network access, and place secrets only in environment variables. The included `schema.sql` documents the RLS target when migrating authentication/database control to Supabase Auth + Postgres RLS.

## Functional coverage
Login/logout; admin/manager/sales employee role checks; persistent lead CRUD; 99Acres-only source; soft delete/restore route; backend search, filters and pagination; duplicate checks; follow-ups (today/upcoming/overdue); calls as follow-up actions; tasks; notes; activity history; properties; users; reports; XLSX/XLS/CSV import with mapping/preview/history; XLSX/CSV export; responsive UI.
